﻿namespace HospitalManagementSystem
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnlogout = new System.Windows.Forms.Button();
            this.btnroom = new System.Windows.Forms.Button();
            this.btnaddstf = new System.Windows.Forms.Button();
            this.tnadddoc = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnlogout
            // 
            this.btnlogout.BackColor = System.Drawing.Color.White;
            this.btnlogout.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.Location = new System.Drawing.Point(445, 300);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Size = new System.Drawing.Size(86, 30);
            this.btnlogout.TabIndex = 3;
            this.btnlogout.Text = "LogOut";
            this.btnlogout.UseVisualStyleBackColor = false;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // btnroom
            // 
            this.btnroom.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnroom.Image = global::HospitalManagementSystem.Properties.Resources.a_hospital_room_with_a_bed_a_drip_and_a_vector_30426365;
            this.btnroom.Location = new System.Drawing.Point(399, 48);
            this.btnroom.Name = "btnroom";
            this.btnroom.Size = new System.Drawing.Size(165, 218);
            this.btnroom.TabIndex = 2;
            this.btnroom.UseVisualStyleBackColor = false;
            this.btnroom.Click += new System.EventHandler(this.btnroom_Click);
            // 
            // btnaddstf
            // 
            this.btnaddstf.Image = global::HospitalManagementSystem.Properties.Resources.staf;
            this.btnaddstf.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnaddstf.Location = new System.Drawing.Point(193, 48);
            this.btnaddstf.Name = "btnaddstf";
            this.btnaddstf.Size = new System.Drawing.Size(186, 223);
            this.btnaddstf.TabIndex = 1;
            this.btnaddstf.UseVisualStyleBackColor = true;
            this.btnaddstf.Click += new System.EventHandler(this.btnaddstf_Click);
            // 
            // tnadddoc
            // 
            this.tnadddoc.Image = global::HospitalManagementSystem.Properties.Resources.doctor_with_stethoscope_medical_uniform_vector_231055581;
            this.tnadddoc.Location = new System.Drawing.Point(12, 51);
            this.tnadddoc.Name = "tnadddoc";
            this.tnadddoc.Size = new System.Drawing.Size(175, 220);
            this.tnadddoc.TabIndex = 0;
            this.tnadddoc.UseVisualStyleBackColor = true;
            this.tnadddoc.Click += new System.EventHandler(this.tnadddoc_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(28, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 22);
            this.label1.TabIndex = 4;
            this.label1.Text = "Doctor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(248, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 22);
            this.label2.TabIndex = 5;
            this.label2.Text = "Staff";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(441, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 22);
            this.label3.TabIndex = 6;
            this.label3.Text = "Room";
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(576, 342);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnlogout);
            this.Controls.Add(this.btnroom);
            this.Controls.Add(this.btnaddstf);
            this.Controls.Add(this.tnadddoc);
            this.MaximumSize = new System.Drawing.Size(594, 389);
            this.MinimumSize = new System.Drawing.Size(594, 389);
            this.Name = "Register";
            this.Text = "Register";
            this.Load += new System.EventHandler(this.Register_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button tnadddoc;
        private System.Windows.Forms.Button btnaddstf;
        private System.Windows.Forms.Button btnroom;
        private System.Windows.Forms.Button btnlogout;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;

    }
}