﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagementSystem
{
    public partial class AdminLogin : Form
    {
        //creating objects
   AdminView av = new AdminView();
    //    MainPage mp = new MainPage();
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            
            
            string user = Convert.ToString(this.textname.Text);
            string password = Convert.ToString(this.txtpass.Text);
            if (user == "Admin" && password == "pass1")
            {
                av.Show();
                this.Hide();
            
            }
            else
            {
                label1.Text = "Incorrect Data";
            }
            
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            MainPage mpg=new MainPage();
            mpg.Show();
            this.Hide();
        }

        private void AdminLogin_Load(object sender, EventArgs e)
        {

        }
    }
}