﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagementSystem
{
    public partial class Appoinments : Form
    {
        public Appoinments()
        {
            InitializeComponent();
        }
        string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;

        private void Appoinments_Load(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            connection.Open();
            string qry = "Select Name,Specialization FROM Doctor";
            SqlDataAdapter sda = new SqlDataAdapter(qry,connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }

        private void btnmapppoinment_Click(object sender, EventArgs e)
        {

            string fname = this.txtfname.Text;
            string lname = this.txtlname.Text;
             int  PhoneNum = Convert.ToInt32(this.txtpnum.Text);
            String disease = this.txtdesease.Text;
            //string male = this.rbmale.Text;
            //string female = this.rbfemale.Text;
             string date = this.txtdate.Text;
             string docname = this.txtdocname.Text;
             string gender = string.Empty;
             if (rbmale.Checked)
             {
                 gender = "Male";
             }
             else
             {
                 gender = "Female";
             }

            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "INSERT INTO Appoinment(FirstName,LastName,PhoneNumber,Disease, DoctorName,Gender,Date) VALUES('" + fname + "','" + lname + "','" + PhoneNum + "','" + disease + "','" + docname + "','" + gender + "','" + date+ "')";
            connection.Open();

            command.ExecuteNonQuery();

            connection.Close();
            label8.Text = " Got Appoinment";
        }

        private void btnregister_Click(object sender, EventArgs e)
        {
            AddPatient adp = new AddPatient();
            adp.Show();
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }

}
