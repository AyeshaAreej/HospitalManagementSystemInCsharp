﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalManagementSystem
{
    public partial class DoctorView : Form
    {
        public DoctorView()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            //write code to change pass and username
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TreatPatient tp = new TreatPatient();
            tp.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SeeAppoinments aps = new SeeAppoinments();
            aps.Show();
            this.Hide();

        }
    }
}
