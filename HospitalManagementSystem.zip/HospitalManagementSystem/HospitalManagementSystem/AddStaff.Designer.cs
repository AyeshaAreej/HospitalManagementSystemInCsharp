﻿namespace HospitalManagementSystem
{
    partial class AddStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtgender = new System.Windows.Forms.TextBox();
            this.btnback = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtjob = new System.Windows.Forms.TextBox();
            this.txtsalary = new System.Windows.Forms.TextBox();
            this.txtphonenum = new System.Windows.Forms.TextBox();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.PhoneNumber = new System.Windows.Forms.Label();
            this.lblsalary = new System.Windows.Forms.Label();
            this.lbljob = new System.Windows.Forms.Label();
            this.lblstaffid = new System.Windows.Forms.Label();
            this.llname = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtgender
            // 
            this.txtgender.Location = new System.Drawing.Point(173, 234);
            this.txtgender.Name = "txtgender";
            this.txtgender.Size = new System.Drawing.Size(136, 22);
            this.txtgender.TabIndex = 38;
            // 
            // btnback
            // 
            this.btnback.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(388, 400);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(106, 42);
            this.btnback.TabIndex = 37;
            this.btnback.Text = "Go Back";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(268, 400);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 41);
            this.button1.TabIndex = 36;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(170, 400);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(92, 41);
            this.btnUpdate.TabIndex = 35;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(29, 400);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(119, 41);
            this.btnAdd.TabIndex = 34;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(466, 146);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(178, 91);
            this.txtaddress.TabIndex = 33;
            // 
            // txtjob
            // 
            this.txtjob.Location = new System.Drawing.Point(173, 280);
            this.txtjob.Name = "txtjob";
            this.txtjob.Size = new System.Drawing.Size(139, 22);
            this.txtjob.TabIndex = 32;
            // 
            // txtsalary
            // 
            this.txtsalary.Location = new System.Drawing.Point(466, 85);
            this.txtsalary.Name = "txtsalary";
            this.txtsalary.Size = new System.Drawing.Size(178, 22);
            this.txtsalary.TabIndex = 31;
            // 
            // txtphonenum
            // 
            this.txtphonenum.Location = new System.Drawing.Point(173, 181);
            this.txtphonenum.Name = "txtphonenum";
            this.txtphonenum.Size = new System.Drawing.Size(139, 22);
            this.txtphonenum.TabIndex = 30;
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.BackColor = System.Drawing.Color.Transparent;
            this.lbladdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdress.Location = new System.Drawing.Point(347, 146);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(92, 25);
            this.lbladdress.TabIndex = 29;
            this.lbladdress.Text = "Address";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.BackColor = System.Drawing.Color.Transparent;
            this.lblgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgender.Location = new System.Drawing.Point(24, 230);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(83, 25);
            this.lblgender.TabIndex = 28;
            this.lblgender.Text = "Gender";
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.AutoSize = true;
            this.PhoneNumber.BackColor = System.Drawing.Color.Transparent;
            this.PhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNumber.Location = new System.Drawing.Point(-1, 178);
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Size = new System.Drawing.Size(149, 25);
            this.PhoneNumber.TabIndex = 27;
            this.PhoneNumber.Text = "PhoneNumber";
            // 
            // lblsalary
            // 
            this.lblsalary.AutoSize = true;
            this.lblsalary.BackColor = System.Drawing.Color.Transparent;
            this.lblsalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsalary.Location = new System.Drawing.Point(347, 85);
            this.lblsalary.Name = "lblsalary";
            this.lblsalary.Size = new System.Drawing.Size(74, 25);
            this.lblsalary.TabIndex = 26;
            this.lblsalary.Text = "Salary";
            // 
            // lbljob
            // 
            this.lbljob.AutoSize = true;
            this.lbljob.BackColor = System.Drawing.Color.Transparent;
            this.lbljob.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbljob.Location = new System.Drawing.Point(12, 290);
            this.lbljob.Name = "lbljob";
            this.lbljob.Size = new System.Drawing.Size(95, 25);
            this.lbljob.TabIndex = 25;
            this.lbljob.Text = "Job type";
            // 
            // lblstaffid
            // 
            this.lblstaffid.AutoSize = true;
            this.lblstaffid.BackColor = System.Drawing.Color.Transparent;
            this.lblstaffid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstaffid.Location = new System.Drawing.Point(12, 81);
            this.lblstaffid.Name = "lblstaffid";
            this.lblstaffid.Size = new System.Drawing.Size(75, 25);
            this.lblstaffid.TabIndex = 24;
            this.lblstaffid.Text = "StaffId";
            // 
            // llname
            // 
            this.llname.AutoSize = true;
            this.llname.BackColor = System.Drawing.Color.Transparent;
            this.llname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llname.Location = new System.Drawing.Point(12, 124);
            this.llname.Name = "llname";
            this.llname.Size = new System.Drawing.Size(68, 25);
            this.llname.TabIndex = 23;
            this.llname.Text = "Name";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(173, 124);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(136, 22);
            this.txtname.TabIndex = 22;
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(173, 81);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(136, 22);
            this.txtid.TabIndex = 21;
            this.txtid.TextChanged += new System.EventHandler(this.txtid_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(167, 270);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 39;
            // 
            // btnLogOut
            // 
            this.btnLogOut.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.Location = new System.Drawing.Point(500, 400);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(125, 42);
            this.btnLogOut.TabIndex = 40;
            this.btnLogOut.Text = "LogOut";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(262, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 41);
            this.label2.TabIndex = 41;
            this.label2.Text = "Add Staff";
            // 
            // AddStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HospitalManagementSystem.Properties.Resources.blur_image_background_waiting_area_hospital_clinic_9693_7821;
            this.ClientSize = new System.Drawing.Size(656, 454);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtgender);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.txtjob);
            this.Controls.Add(this.txtsalary);
            this.Controls.Add(this.txtphonenum);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lblgender);
            this.Controls.Add(this.PhoneNumber);
            this.Controls.Add(this.lblsalary);
            this.Controls.Add(this.lbljob);
            this.Controls.Add(this.lblstaffid);
            this.Controls.Add(this.llname);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtid);
            this.MaximumSize = new System.Drawing.Size(674, 501);
            this.MinimumSize = new System.Drawing.Size(674, 501);
            this.Name = "AddStaff";
            this.Text = "AddStaff";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtgender;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtjob;
        private System.Windows.Forms.TextBox txtsalary;
        private System.Windows.Forms.TextBox txtphonenum;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label PhoneNumber;
        private System.Windows.Forms.Label lblsalary;
        private System.Windows.Forms.Label lbljob;
        private System.Windows.Forms.Label lblstaffid;
        private System.Windows.Forms.Label llname;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label label2;

    }
}