﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagementSystem
{
    public partial class PatientInformation : Form
    {
        public PatientInformation()
        {
            InitializeComponent();
        }

        private void btninfo_Click(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            connection.Open();
            string qry = "Select * FROM Patient Where Name = '" + this.txtpname.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(qry, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PatientView patientvw = new PatientView();
            patientvw.Show();
            this.Hide();
        }
    }
}
