﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagementSystem
{
    public partial class TreatPatient : Form
    {
        public TreatPatient()
        {
            InitializeComponent();
            
        }

        private void TreatPatient_Load(object sender, EventArgs e)
        {

        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            connection.Open();
            string qry = "Delete FROM Appoinment Where Id= '" + this.txtid.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(qry, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
            label5.Text = "Treated Patient Record Deleated";
        }

        private void txtdocname_TextChanged(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            connection.Open();
            string qry = "Select Id,FirstName,LastName,Gender,Disease,Date FROM Appoinment Where DoctorName = '" + this.txtdocname.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(qry, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            DoctorView dot = new DoctorView();
            dot.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            connection.Open();
            string qry = "Select Id,FirstName,LastName,Gender,Disease,Date FROM Appoinment Where DoctorName = '" + this.txtdocname.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(qry, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }
    }
}
