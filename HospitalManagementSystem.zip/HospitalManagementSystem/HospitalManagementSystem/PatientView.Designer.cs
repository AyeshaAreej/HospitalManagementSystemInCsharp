﻿namespace HospitalManagementSystem
{
    partial class PatientView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnpinfo = new System.Windows.Forms.Button();
            this.btnadmit = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnpinfo
            // 
            this.btnpinfo.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpinfo.Location = new System.Drawing.Point(266, 91);
            this.btnpinfo.Name = "btnpinfo";
            this.btnpinfo.Size = new System.Drawing.Size(152, 42);
            this.btnpinfo.TabIndex = 0;
            this.btnpinfo.Text = "PatientInfo";
            this.btnpinfo.UseVisualStyleBackColor = true;
            this.btnpinfo.Click += new System.EventHandler(this.btnpinfo_Click);
            // 
            // btnadmit
            // 
            this.btnadmit.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadmit.Location = new System.Drawing.Point(266, 22);
            this.btnadmit.Name = "btnadmit";
            this.btnadmit.Size = new System.Drawing.Size(152, 42);
            this.btnadmit.TabIndex = 1;
            this.btnadmit.Text = "Admit Patient";
            this.btnadmit.UseVisualStyleBackColor = true;
            this.btnadmit.Click += new System.EventHandler(this.btnadmit_Click);
            // 
            // btnback
            // 
            this.btnback.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(52, 289);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(75, 42);
            this.btnback.TabIndex = 4;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnclose
            // 
            this.btnclose.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose.Location = new System.Drawing.Point(343, 289);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(75, 42);
            this.btnclose.TabIndex = 5;
            this.btnclose.Text = "Close";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // PatientView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HospitalManagementSystem.Properties.Resources.patient_satisfaction_in_healthcare_1_920x518;
            this.ClientSize = new System.Drawing.Size(453, 343);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnadmit);
            this.Controls.Add(this.btnpinfo);
            this.MaximumSize = new System.Drawing.Size(471, 390);
            this.MinimumSize = new System.Drawing.Size(471, 390);
            this.Name = "PatientView";
            this.Text = "PatientView";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnpinfo;
        private System.Windows.Forms.Button btnadmit;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnclose;
    }
}