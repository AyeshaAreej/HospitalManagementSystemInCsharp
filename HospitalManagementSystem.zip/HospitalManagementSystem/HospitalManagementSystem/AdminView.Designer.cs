﻿namespace HospitalManagementSystem
{
    partial class AdminView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminView));
            this.btnviewpatient = new System.Windows.Forms.Button();
            this.btndocinfo = new System.Windows.Forms.Button();
            this.btnstaffinfo = new System.Windows.Forms.Button();
            this.btnappoinment = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnroominfo = new System.Windows.Forms.Button();
            this.btndeleteuser = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnviewpatient
            // 
            this.btnviewpatient.BackColor = System.Drawing.Color.White;
            this.btnviewpatient.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnviewpatient.Location = new System.Drawing.Point(12, 69);
            this.btnviewpatient.Name = "btnviewpatient";
            this.btnviewpatient.Size = new System.Drawing.Size(183, 38);
            this.btnviewpatient.TabIndex = 0;
            this.btnviewpatient.Text = "ViewPatients";
            this.btnviewpatient.UseVisualStyleBackColor = false;
            this.btnviewpatient.Click += new System.EventHandler(this.btnviewpatient_Click);
            // 
            // btndocinfo
            // 
            this.btndocinfo.BackColor = System.Drawing.Color.White;
            this.btndocinfo.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndocinfo.Location = new System.Drawing.Point(12, 12);
            this.btndocinfo.Name = "btndocinfo";
            this.btndocinfo.Size = new System.Drawing.Size(183, 40);
            this.btndocinfo.TabIndex = 1;
            this.btndocinfo.Text = "Doctor Info";
            this.btndocinfo.UseVisualStyleBackColor = false;
            this.btndocinfo.Click += new System.EventHandler(this.btndocinfo_Click);
            // 
            // btnstaffinfo
            // 
            this.btnstaffinfo.BackColor = System.Drawing.Color.White;
            this.btnstaffinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstaffinfo.Location = new System.Drawing.Point(12, 113);
            this.btnstaffinfo.Name = "btnstaffinfo";
            this.btnstaffinfo.Size = new System.Drawing.Size(183, 34);
            this.btnstaffinfo.TabIndex = 2;
            this.btnstaffinfo.Text = "Staff Info";
            this.btnstaffinfo.UseVisualStyleBackColor = false;
            this.btnstaffinfo.Click += new System.EventHandler(this.btnstaffinfo_Click);
            // 
            // btnappoinment
            // 
            this.btnappoinment.BackColor = System.Drawing.Color.White;
            this.btnappoinment.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnappoinment.Location = new System.Drawing.Point(12, 215);
            this.btnappoinment.Name = "btnappoinment";
            this.btnappoinment.Size = new System.Drawing.Size(183, 38);
            this.btnappoinment.TabIndex = 3;
            this.btnappoinment.Text = "Appoinments";
            this.btnappoinment.UseVisualStyleBackColor = false;
            this.btnappoinment.Click += new System.EventHandler(this.btnappoinment_Click);
            // 
            // btnLogOut
            // 
            this.btnLogOut.BackColor = System.Drawing.Color.White;
            this.btnLogOut.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.Location = new System.Drawing.Point(339, 360);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(155, 30);
            this.btnLogOut.TabIndex = 5;
            this.btnLogOut.Text = "LogOut";
            this.btnLogOut.UseVisualStyleBackColor = false;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(2, 339);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(226, 35);
            this.button2.TabIndex = 6;
            this.button2.Text = "Patient Check Out";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(201, 26);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(383, 296);
            this.dataGridView1.TabIndex = 7;
            // 
            // btnroominfo
            // 
            this.btnroominfo.BackColor = System.Drawing.Color.White;
            this.btnroominfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnroominfo.Location = new System.Drawing.Point(12, 162);
            this.btnroominfo.Name = "btnroominfo";
            this.btnroominfo.Size = new System.Drawing.Size(183, 32);
            this.btnroominfo.TabIndex = 8;
            this.btnroominfo.Text = "Room Info";
            this.btnroominfo.UseVisualStyleBackColor = false;
            this.btnroominfo.Click += new System.EventHandler(this.btnroominfo_Click);
            // 
            // btndeleteuser
            // 
            this.btndeleteuser.BackColor = System.Drawing.Color.White;
            this.btndeleteuser.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndeleteuser.Location = new System.Drawing.Point(12, 268);
            this.btndeleteuser.Name = "btndeleteuser";
            this.btndeleteuser.Size = new System.Drawing.Size(183, 34);
            this.btndeleteuser.TabIndex = 9;
            this.btndeleteuser.Text = "Delete User";
            this.btndeleteuser.UseVisualStyleBackColor = false;
            this.btndeleteuser.Click += new System.EventHandler(this.btndeleteuser_Click);
            // 
            // AdminView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(591, 429);
            this.Controls.Add(this.btndeleteuser);
            this.Controls.Add(this.btnroominfo);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnappoinment);
            this.Controls.Add(this.btnstaffinfo);
            this.Controls.Add(this.btndocinfo);
            this.Controls.Add(this.btnviewpatient);
            this.MaximumSize = new System.Drawing.Size(609, 476);
            this.MinimumSize = new System.Drawing.Size(609, 476);
            this.Name = "AdminView";
            this.Text = "AdminView";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnviewpatient;
        private System.Windows.Forms.Button btndocinfo;
        private System.Windows.Forms.Button btnstaffinfo;
        private System.Windows.Forms.Button btnappoinment;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnroominfo;
        private System.Windows.Forms.Button btndeleteuser;

    }
}