﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagementSystem
{
    public partial class AdminRegister : Form
    {
        //creating Objects
        MainPage manpg = new MainPage();
        Register regster = new Register();
        public AdminRegister()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            manpg.Show();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string user = Convert.ToString(this.textname.Text);
            string password = Convert.ToString(this.txtpass.Text);
            if (user == "Admin" && password == "pass1")
            {
                regster.Show();
                this.Hide();


            }
            else
            {
                label1.Text = "Incorrect Data";
            }
            

           
        }
    }
}
