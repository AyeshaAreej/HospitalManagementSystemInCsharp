﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagementSystem
{
    public partial class AddPatient : Form
    {
        public AddPatient()
        {
            InitializeComponent();
        }
        string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;

        private void button1_Click(object sender, EventArgs e)
        {
           

           
            string name = this.txtpname.Text;
            string PhoneNum = this.txtphnum.Text;
            string disease = this.txtdisease.Text;
            string sofdisease = this.txtsdesease.Text;
            string gender = this.txtgender.Text;
            string rmnum = this.txtrmnum.Text;
            string rmtype = this.txtrmtype.Text;
          


            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "INSERT INTO Patient(Name,PhoneNumber,Disease,DiseaseStatus, RoomNum,RoomType,Gender) VALUES('" + name + "','" + PhoneNum + "','" + disease + "','" + sofdisease + "','" + gender + "','" + rmnum + "','" + rmtype + "')";
            connection.Open();

            command.ExecuteNonQuery();

            connection.Close();
            label7.Text = "Patient Added";





        }

        private void AddPatient_Load(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            connection.Open();
            string qry = "Select * FROM Rooms";
            SqlDataAdapter sda = new SqlDataAdapter(qry, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PatientView pvw = new PatientView();
            pvw.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
