﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalManagementSystem
{
    public partial class Register : Form
    {
        //cfreating objects
        AddDoctor ad = new AddDoctor();
        public Register()
        {
            InitializeComponent();
        }

        private void btnaddstf_Click(object sender, EventArgs e)
        {
            AddStaff ast =new AddStaff();
            ast.Show();
            this.Hide();
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }

        private void tnadddoc_Click(object sender, EventArgs e)
        {
            ad.Show();
            this.Hide();
        }

        private void btnroom_Click(object sender, EventArgs e)
        {
            AddRoom ar = new AddRoom();
            ar.Show();
            this.Hide();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
