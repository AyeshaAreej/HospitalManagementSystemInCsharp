﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagementSystem
{
    public partial class AddStaff : Form
    {
        string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;

        public AddStaff()
        {
            InitializeComponent();
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            String salary = this.txtsalary.Text;
            String PhoneNum = this.txtphonenum.Text;
            string name = this.txtname.Text;
            string jobtype = this.txtjob.Text;
            string gender = this.txtgender.Text;
            string addr = this.txtaddress.Text;
           
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "INSERT INTO Staffs (Name,PhoneNumber,Salary,JobType,Address,Gender) VALUES('" + name + "','" + PhoneNum + "','" + salary + "','" + jobtype + "','" + addr + "','" + gender + "')";
            connection.Open();

            command.ExecuteNonQuery();

            connection.Close();
            label1.Text = "Record Added";

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
          String salary = this.txtsalary.Text;
            String PhoneNum = this.txtphonenum.Text;
            string name = this.txtname.Text;
            string jobtype = this.txtjob.Text;
            string gender = this.txtgender.Text;
            string addr = this.txtaddress.Text;
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "Update Staffs SET Name = '" + name + "',PhoneNumber = '" + PhoneNum + "',Salary = '" + salary + "',JobType= '" + jobtype + "',Address= '" + addr + "',Gender= '" + gender + "' " + " Where Id = '" + txtid.Text + "'";
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
            label1.Text = "Record Updated";
        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "DELETE from Staffs Where Name = '" + txtname.Text + "'";
            connection.Open();
            command.ExecuteNonQuery();
            label1.Text = "Record Deleted";
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Register regstr = new Register();
            regstr.Show();
            this.Hide();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
