﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalManagementSystem
{
    public partial class MainPage : Form
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnregister_Click(object sender, EventArgs e)
        {
            AdminRegister mnl = new AdminRegister();
            mnl.Show();

           
        }

        private void btnadmin_Click(object sender, EventArgs e)
        {
            AdminLogin al = new AdminLogin();
            al.Show();
            this.Hide();
        }

        private void btndoctor_Click(object sender, EventArgs e)
        {
            DoctorLogin docl = new DoctorLogin();
            docl.Show();
            this.Hide();
            
        }

        private void btnpatient_Click(object sender, EventArgs e)
        {
            PatientView ptv = new PatientView();
            ptv.Show();
            this.Hide();
        }

        private void btnAppoinment_Click(object sender, EventArgs e)
        {
            Appoinments aps = new Appoinments();
            aps.Show();
            this.Hide();
        }

        private void btnabout_Click(object sender, EventArgs e)
        {
            /*About abt = new About();
            abt.Show();*/
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void developerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About ab = new About();
            ab.Show();
            this.Hide();
        }

        private void projectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            aboutproject abprjt = new aboutproject();
            abprjt.Show();
            this.Hide();
        }
    }
}
