﻿namespace HospitalManagementSystem
{
    partial class DoctorLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnlogin = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.textname = new System.Windows.Forms.TextBox();
            this.lblpass = new System.Windows.Forms.Label();
            this.lbluname = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnlogin
            // 
            this.btnlogin.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogin.Location = new System.Drawing.Point(249, 187);
            this.btnlogin.Name = "btnlogin";
            this.btnlogin.Size = new System.Drawing.Size(79, 35);
            this.btnlogin.TabIndex = 11;
            this.btnlogin.Text = "LogIn";
            this.btnlogin.UseVisualStyleBackColor = true;
            this.btnlogin.Click += new System.EventHandler(this.btnlogin_Click);
            // 
            // btnback
            // 
            this.btnback.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(109, 187);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(75, 35);
            this.btnback.TabIndex = 10;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(228, 127);
            this.txtpass.Name = "txtpass";
            this.txtpass.PasswordChar = '*';
            this.txtpass.Size = new System.Drawing.Size(131, 22);
            this.txtpass.TabIndex = 9;
            // 
            // textname
            // 
            this.textname.Location = new System.Drawing.Point(228, 57);
            this.textname.Name = "textname";
            this.textname.Size = new System.Drawing.Size(131, 22);
            this.textname.TabIndex = 8;
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.BackColor = System.Drawing.Color.Transparent;
            this.lblpass.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpass.Location = new System.Drawing.Point(86, 127);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(94, 22);
            this.lblpass.TabIndex = 7;
            this.lblpass.Text = "Password";
            // 
            // lbluname
            // 
            this.lbluname.AutoSize = true;
            this.lbluname.BackColor = System.Drawing.Color.Transparent;
            this.lbluname.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbluname.Location = new System.Drawing.Point(80, 62);
            this.lbluname.Name = "lbluname";
            this.lbluname.Size = new System.Drawing.Size(101, 22);
            this.lbluname.TabIndex = 6;
            this.lbluname.Text = "UserName";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(160, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 12;
            // 
            // DoctorLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HospitalManagementSystem.Properties.Resources.doctor_with_stethoscope_hands_hospital_background_1423_1;
            this.ClientSize = new System.Drawing.Size(448, 253);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnlogin);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.textname);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.lbluname);
            this.MaximumSize = new System.Drawing.Size(466, 300);
            this.MinimumSize = new System.Drawing.Size(466, 300);
            this.Name = "DoctorLogin";
            this.Text = "DoctorLogin";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnlogin;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.TextBox textname;
        private System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.Label lbluname;
        private System.Windows.Forms.Label label1;
    }
}