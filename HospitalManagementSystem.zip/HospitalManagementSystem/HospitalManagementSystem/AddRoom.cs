﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagementSystem
{
    public partial class AddRoom : Form
    {
        string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
        public AddRoom()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(this.txtrooomnum.Text);
            int price = Convert.ToInt32(this.txtprice.Text);
            string floor = this.txtfloor.Text;
            string roomtype = this.txtrmtype.Text;
           

          

            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "INSERT INTO Rooms (RoomNumber,RoomType,Floor,Price) VALUES('" + num+"','" + roomtype + "','" + floor + "','"+price+"')";
            connection.Open();

            command.ExecuteNonQuery();

            connection.Close();
          label6.Text = "Record Added";

        }

        private void AddRoom_Load(object sender, EventArgs e)
        {

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "Update Rooms SET RoomNumber = '" + txtrooomnum.Text + "',RoomType = '" + txtrmtype.Text + "',Floor = '" + txtfloor.Text + "',Price= '" + txtprice.Text + "'" +
                " Where RoomNumber = '" + txtrooomnum.Text + "'";
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
            label6.Text = "Record Updated";

        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Register rg = new Register();
            rg.Show();
            this.Hide();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "DELETE from Rooms Where RoomNumber = '" + txtrooomnum.Text + "'";
            connection.Open();
            command.ExecuteNonQuery();
            label6.Text = "Record Deleted";
        }
    }
}
