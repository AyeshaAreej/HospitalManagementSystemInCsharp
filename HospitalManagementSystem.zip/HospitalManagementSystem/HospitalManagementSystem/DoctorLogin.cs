﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagementSystem
{
    public partial class DoctorLogin : Form
    {
        public DoctorLogin()
        {
            InitializeComponent();
        }
        //Creating objects of formsdsahfsdfajgfa
        DoctorView doctv = new DoctorView();
        private void btnback_Click(object sender, EventArgs e)
        {
            MainPage mnpg = new MainPage();
            mnpg.Show();
            this.Hide();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
            string user = Convert.ToString(this.textname.Text);
            string password = Convert.ToString(this.txtpass.Text);

            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.CommandText = "Select * from Member";
            command.Connection = connection;
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
           
            while (reader.Read())
            {

                int id = (int)reader[0];
                string username1 = (string)reader["UserName"];
                string passwrd = (string)reader["Password"];

                if (user == username1 && password == passwrd)
                {

                    label1.Text = "Correct Data";
                    doctv.Show();
                    this.Hide();
                }
                else
                {
                    label1.Text = "Incorrect Data";
                }

            }
            reader.Close();
            connection.Close();
        
        }
    }
}
