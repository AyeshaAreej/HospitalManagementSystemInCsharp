﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagementSystem
{
    public partial class AddDoctor : Form
    {
        string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
        public AddDoctor()
        {
            InitializeComponent();
        }
      
        private void lblgender_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
      //     int id = Convert.ToInt32(this.txtid.Text);
            String salary = this.txtsalary.Text;
            string PhoneNum = this.txtphonenum.Text;
            string name = this.txtname.Text;
            string gender = this.txtgender.Text;
            string addr = this.xtaddress.Text;
            string specialization = this.txtspecialization.Text;
         
         

            SqlConnection connection = new SqlConnection(connectionstring);   
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "INSERT INTO Doctor(Name,PhoneNum,Salary,Specialization,Address,Gender) VALUES('" + name + "','" + PhoneNum + "','" + salary + "','" + specialization + "','" + addr + "','" + gender + "')";
            connection.Open();

            command.ExecuteNonQuery();

            connection.Close();
            label1.Text = "Record Added";
            //assigning username and pass

            command.CommandText = "INSERT INTO Member(UserName,Password) VALUES('" + this.txtuname.Text + "','" + this.txtpass.Text + "')";
            connection.Open();

            command.ExecuteNonQuery();

            connection.Close();
            //label1.Text = "Record Added";

        }

        private void AddDoctor_Load(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            
        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            String salary = this.txtsalary.Text;
            String PhoneNum = this.txtphonenum.Text;
            string name = this.txtname.Text;
            string gender = this.txtgender.Text;
            string addr = this.xtaddress.Text;
            string specialization = this.txtspecialization.Text;

            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "Update Doctor SET Name = '" + name + "',PhoneNum = '" + PhoneNum + "',Salary = '" + salary + "',Specialization= '" + specialization + "',Address= '" + addr + "',Gender= '" + gender + "' " + " Where Id = '" + txtid.Text + "'";
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
            label1.Text = "Record Updated";
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Register regst = new Register();
            regst.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "DELETE from Doctor Where Id = '" + txtid.Text + "'";
            connection.Open();
            command.ExecuteNonQuery();
            label1.Text = "Record Deleted";
        }
    }
}
