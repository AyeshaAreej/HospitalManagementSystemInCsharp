﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace HospitalManagementSystem
{
    public partial class Members : Form
    {
        public Members()
        {
            InitializeComponent();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            AdminView admnvw = new AdminView();
            admnvw.Show();
            this.Hide();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            connection.Open();
            string qry = "Delete FROM Member Where Id= '" + this.txtuid.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(qry, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
           

        }

        private void Members_Load(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            connection.Open();
            string qry = "Select  * FROM Member ";
            SqlDataAdapter sda = new SqlDataAdapter(qry, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }

        private void btnvwr_Click(object sender, EventArgs e)
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["mystring"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            connection.Open();
            string qry = "Select  * FROM Member ";
            SqlDataAdapter sda = new SqlDataAdapter(qry, connection);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            connection.Close();
        }
    }
}
